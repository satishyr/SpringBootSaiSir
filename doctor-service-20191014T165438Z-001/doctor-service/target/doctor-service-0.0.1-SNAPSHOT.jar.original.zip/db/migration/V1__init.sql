create table doctor(id integer primary key auto_increment,name varchar(20),specialization varchar(20));

insert into doctor(name,specialization) values('doctor1','Ortho');
insert into doctor(name,specialization) values('doctor2','Cardio');