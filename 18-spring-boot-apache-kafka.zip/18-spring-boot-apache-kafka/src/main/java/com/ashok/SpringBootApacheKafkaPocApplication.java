package com.ashok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * @author Ashok
 *
 */
@SpringBootApplication
public class SpringBootApacheKafkaPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApacheKafkaPocApplication.class, args);
	}
}
