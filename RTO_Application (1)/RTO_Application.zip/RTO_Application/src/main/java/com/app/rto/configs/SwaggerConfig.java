package com.app.rto.configs;

import static springfox.documentation.builders.PathSelectors.any;
import static springfox.documentation.builders.RequestHandlerSelectors.basePackage;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.service.Contact;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * This is class to provide swagger support to our application 
 * it provide both swagger UI as well as Swagger documnetation
 * 
 * @author Satishkumar
 *
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

	/**
	 * THis is used to create Docket Object to show the swagger ui
	 * provide the location of Rest Controllers 
	 * @return Docket
	 */
	@Bean
	public Docket docket() {
		Docket docket=new Docket(DocumentationType.SWAGGER_2)
					.select()
					.apis(basePackage("com.app.rto.rest"))
					.paths(any())
					.build()
					.apiInfo(apiInfo1());
		return docket;
		
	}
	private ApiInfo apiInfo1() {
		ApiInfo builder=new ApiInfoBuilder()
								.title("NARESH TECH SOLUTION Pvt.Ltd")
								.description("User Apllication ")
								.contact(new Contact("satish kumar","9912233329", "y.satishkumar34@gmail.com"))
								.license("Apache 2.0")
								.licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
								.build();
		return builder;
	}
	
}