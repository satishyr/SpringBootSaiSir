package com.app.rto.controllers;


import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.rto.constants.AppConstant;
import com.app.rto.model.VehicleDetails;
import com.app.rto.model.VehicleOwnerDetails;
import com.app.rto.services.VehicleOwnerDetailsService;
/**
 * this Controller is used to handle request comes for  VehicleOwnerDetails related Ui
 * 
 *  @author Satishkumar
 */
@Controller
public class VehicleOwnerDetailsController {
	/**
	 * inject VehicleOwnerDetails service to perform business operation 
	 */
	@Autowired
	private VehicleOwnerDetailsService service;
	
	
	private static Logger log=Logger.getLogger(VehicleOwnerDetailsController.class);
	/**
	 * this is used to populate the initial form when the first request comes in our application
	 * with binding object 
	 * 
	 * @param model
	 * @return String 
	 */
	@RequestMapping("/getForm")
	public String getForm(Model model) {
		BasicConfigurator.configure();
		log.info("***Start vehicle owner details loadform metod***");
		VehicleOwnerDetails ownerdetails=new VehicleOwnerDetails();
		model.addAttribute(AppConstant.MODEL_ATTR_KEY_OWNER_DTLS, ownerdetails);
		log.info("****end vehicle owner details loadform method****");
		return AppConstant.LOGICAL_OWNER_DTLS_VIEW;
		
	}
	
	/**
	 * this method is used to capture the data from VehicleOwnerDetails UI and send that data to service
	 * layer and from that store data in database and we get primary key 
	 * 
	 * @param ownerDtls
	 * @param ownerid
	 * @param model
	 * @return String
	 */
	@RequestMapping(value="/saveDtls",method =RequestMethod.POST)
	public String saveOwnerDtls(@ModelAttribute("vehicleOwnerDtls") VehicleOwnerDetails ownerDtls
			,@RequestParam("ownerId") Integer ownerid,Model model) {
		log.info("****start save vehicle owner details save  method****");
			if(ownerid!=null && ownerid>0) {
				ownerDtls.setVhclOwnerid(ownerid);
			}
			VehicleDetails  details=new VehicleDetails();
			//System.out.println(ownerDtls);
			Integer vehicleOwnerKey = service.saveOwnerAddr(ownerDtls);
			model.addAttribute(AppConstant.MODEL_ATTR_KEY_FOR_OWNER_PK, vehicleOwnerKey);
			model.addAttribute(AppConstant.MODEL_ATTR_KEY_VEHICLE_DTLS, details);
			log.info("****end save vehicle owner details save method****");
			return AppConstant.LOGICAL_VEHICLE_DTLS_VIEW;
	}
	/**
	 * This method is used to show VehicleOwnerDetails UI with Data when user 
	 * click on previous hyperlink
	 * @param ownKey
	 * @param model
	 * @return String 
	 */
	@RequestMapping("/prevToOwnerDtls")
	public String getVhclOwnerData(@RequestParam("ownkey") Integer ownKey,Model model) {
		log.info("****start previous button vehicle owner details previvous method****");
		VehicleOwnerDetails ownerdetails=service.findById(ownKey);		
		model.addAttribute(AppConstant.MODEL_ATTR_KEY_OWNER_DTLS, ownerdetails);
		log.info("****end previous button vehicle owner details previous  method****");
		return AppConstant.LOGICAL_OWNER_DTLS_VIEW;
	}
}	