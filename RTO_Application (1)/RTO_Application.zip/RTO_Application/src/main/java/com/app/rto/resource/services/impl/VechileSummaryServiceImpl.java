package com.app.rto.resource.services.impl;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.app.rto.model.VehicleDetails;
import com.app.rto.model.VehicleOwnerAddress;
import com.app.rto.model.VehicleOwnerDetails;
import com.app.rto.model.VehicleRegistrationDtls;
import com.app.rto.resource.binding.VehicleSummary;
import com.app.rto.resource.services.VehicleSummaryServices;
import com.app.rto.services.VchlRegistrationDetailsService;
import com.app.rto.services.VehicleDetailsService;
import com.app.rto.services.VehicleOwnerAddressService;
import com.app.rto.services.VehicleOwnerDetailsService;
/**
 * 
 * This is the implementation for Rest Service provide service to rest resource
 * @author Satishkumar
 *
 */
@Service
public class VechileSummaryServiceImpl implements VehicleSummaryServices{

	/**
	 * Autowiring or inject the  vhclRegservice to get  registration details 
	 */
	@Autowired
	private VchlRegistrationDetailsService  vhclRegservice;
	
	/**
	 * Autowiring or inject the  vhclDetailService to get vehicle Details 
	 */
	@Autowired
	private VehicleDetailsService  vhclDetailService;
	/**
	 * Autowiring or inject the  vhclOwnerDtls to get vehicle Owner details 
	 */
	@Autowired
	private VehicleOwnerDetailsService vhclOwnerDtls;
	/**
	 * Autowiring or inject the  vhclAddrDts to get vehicle Owner Address details
	 */
	@Autowired
	private VehicleOwnerAddressService vhclAddrDts;
	
	/**
	 * Overide that service class method to other four model service and collect all data
	 * and set in the Vehicle summary class 
	 */
	@Override
	public VehicleSummary findVehicleDetails(String regNum) {
		VehicleSummary summary=new VehicleSummary();
		VehicleRegistrationDtls vechicleData = vhclRegservice.findbyRegNum(regNum);
		Integer vhclOwnerid = vechicleData.getDtlsEntity().getVhclOwnerid();
		VehicleDetails vehicleDetails = vhclDetailService.findVehicleByOwnerId(vhclOwnerid);
		VehicleOwnerDetails ownerDetails = vhclOwnerDtls.findById(vhclOwnerid);
		VehicleOwnerAddress address = vhclAddrDts.findAddrbyOwnerId(vhclOwnerid);
		
		summary.setOwnerDetails(ownerDetails);
		summary.setVhclDtls(vehicleDetails);
		summary.setOwnerAddr(address);
		summary.setRegDlts(vechicleData);
		
		return summary;
	}
	
	
	
}
