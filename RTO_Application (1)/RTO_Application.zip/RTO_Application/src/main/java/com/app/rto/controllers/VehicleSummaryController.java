package com.app.rto.controllers;

import javax.mail.MessagingException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.rto.constants.AppConstant;
import com.app.rto.mail.sender.MailSenderUtil;
import com.app.rto.model.VehicleDetails;
import com.app.rto.model.VehicleOwnerAddress;
import com.app.rto.model.VehicleOwnerDetails;
import com.app.rto.model.VehicleRegistrationDtls;
import com.app.rto.properties.AppProperties;
import com.app.rto.services.VchlRegistrationDetailsService;
import com.app.rto.services.VehicleDetailsService;
import com.app.rto.services.VehicleOwnerAddressService;
import com.app.rto.services.VehicleOwnerDetailsService;
/**
 * this Controller is used to handle request for VehicleSummary
 * after filling all form we need show the summary page 
 * with all data
 * @author Satishkumar 
 */
@Controller
public class VehicleSummaryController {
	/**
	 * inject VchlRegistrationDetailsService for fetching registration related data 
	 */
	@Autowired
	private VchlRegistrationDetailsService  vhclRegservice;
	/**
	 * inject VehicleDetailsService for fetching vehicle Details related data
	 */
	@Autowired
	private VehicleDetailsService  vhclDetailService;
	/**
	 * inject VehicleOwnerDetailsService for fetching vehicleowner dtls related data
	 */
	@Autowired
	private VehicleOwnerDetailsService vhclOwnerDtls;
	/**
	 * inject VehicleOwnerAddressService for fetching vehicleOwnerAddrress related data
	 */
	@Autowired
	private VehicleOwnerAddressService vhclAddrDts;
	/**
	 * inject AppProperties to fetch msg which is available in cache  
	 */
	@Autowired
	private AppProperties props;
	/**
	 * this is used to send all data in with successful registration page and show all data in
	 * tabular format in UI and  
	 * @param regNum
	 * @param model
	 * @return String 
	 */
	/**
	 * inject mail object for sending mail
	 */
	@Autowired
	private MailSenderUtil mailSender;
	
	

	private static Logger log=Logger.getLogger(VehicleSummaryController.class);
	
	@RequestMapping("/summary")
	public String getAllDetails(@RequestParam("regNum") String regNum,Model model) throws MessagingException {
		BasicConfigurator.configure();
		log.info("***Start vehicle Summary details get all method***");
		
		VehicleRegistrationDtls vechicleData = vhclRegservice.findbyRegNum(regNum);
	
			Integer vhclOwnerid = vechicleData.getDtlsEntity().getVhclOwnerid();
				VehicleDetails vehicleDetails = vhclDetailService.findVehicleByOwnerId(vhclOwnerid);
				VehicleOwnerDetails ownerDetails = vhclOwnerDtls.findById(vhclOwnerid);
				VehicleOwnerAddress address = vhclAddrDts.findAddrbyOwnerId(vhclOwnerid);
				
				boolean sendMail = mailSender.sendMail(ownerDetails.getEmail(),address.getCity(),vechicleData.getVehicleRegNumber(),vehicleDetails.getVehicleType());
				
				log.info("mail Sending Status===================>"+sendMail);
				String msg = props.getMessages().get(AppConstant.MODEL_ATTR_SUCC_MSG);
				model.addAttribute(AppConstant.MODEL_ATTR_SUCC_MSG_KEY, msg);
				model.addAttribute(AppConstant.MODEL_ATTR_KEY_OWNER_ADDR_DTLS,address);
				model.addAttribute(AppConstant.MODEL_ATTR_KEY_OWNER_DTLS, ownerDetails);
				model.addAttribute(AppConstant.MODEL_ATTR_KEY_VCHL_REG_SUMMARY, vechicleData);
				model.addAttribute(AppConstant.MODEL_ATTR_KEY_VEHICLE_DTLS,vehicleDetails);
				log.info("***end vehicle Summary details getall metod***");
				
				return AppConstant.LOGICAL_VHCL_SUMMARY_VIEW;
	}
}
