package com.app.rto.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.rto.entity.VehicleOwnerDtlsEntity;
/**
 * this repository is used to perform operiton on VehicleOwnerDtlsEntity data  in db side
 *  
 *  @author Satishkumar
 */
public interface VhclOwnerDtlsRepository extends JpaRepository<VehicleOwnerDtlsEntity, Integer>{

}
